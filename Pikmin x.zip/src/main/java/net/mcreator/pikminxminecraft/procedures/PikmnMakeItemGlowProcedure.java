package net.mcreator.pikminxminecraft.procedures;

import net.mcreator.pikminxminecraft.PikminXMinecraftModElements;

import java.util.Map;

@PikminXMinecraftModElements.ModElement.Tag
public class PikmnMakeItemGlowProcedure extends PikminXMinecraftModElements.ModElement {
	public PikmnMakeItemGlowProcedure(PikminXMinecraftModElements instance) {
		super(instance, 3);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
